<?php

class block_autosubscription extends block_base {
    public function init() {
        $this->title = get_string('autosubscription', 'block_autosubscription');
    }
    public function get_config_for_external() {
        // Return all settings for all users since it is safe (no private keys, etc..).
        $configs = !empty($this->config) ? $this->config : new stdClass();

        return (object) [
            'instance' => $configs,
            'plugin' => new stdClass(),
        ];
    }
    function instance_allow_multiple() {
        return true;
    }

    function has_config() {
        return true;
    }

    function applicable_formats() {
        return array('all' => true);
    }

    function instance_allow_config() {
        return true;
    }
    // The PHP tag and the curly bracket for the class definition 
    // will only be closed after there is another function added in the next section.
    public function get_content() {
        global $USER, $COURSE, $DB;
       
        if(!$USER->id)
            return '';

        if ($this->content !== null) {
            return $this->content;
        }

        $this->content          =  new stdClass;
        $this->content->text    = '';
        $this->errors           = [];
        $courses                = get_courses();

        $bcurrentenrolled       = false;
        $checkcourses           = array();
        $minusercount           = 32000;
        $bestcourse             = null;

        foreach($courses as $course) {

            if($this->isAutoCourse($course)) {

                $context = context_course::instance($course->id);


                $checkcourse                = new stdclass();
                $checkcourse->course        = $course;
                $checkcourse->enrolled      = get_enrolled_users($context);
                if(!$checkcourse->enrolled)
                    $checkcourse->enrolled = array();
                $checkcourse->usercount     = count($checkcourse->enrolled);
                
                if($checkcourse->usercount < $minusercount) {
                    $minusercount   = $checkcourse->usercount;
                    $bestcourse     = $checkcourse;
                }
                $checkcourse->isforcurrent  = false;
                if(is_enrolled($context, $USER)) {
                    $bcurrentenrolled           = true;
                    $checkcourse->isforcurrent  = true;
                    $bestcourse = $checkcourse;
                    break;
                }

                $checkcourses[] = $checkcourse;

            }
        }

        if(!$bestcourse) {
            $this->errors[] = 'no course for autosubscription available';
            return $this->writeErrors($this->content);
        }

        if($bcurrentenrolled) {
            $this->content->text .= '<p class="autosubinfo">' .   get_string('alreadyenrolled', 'block_autosubscription') . ':</p>' . '<b>' . $bestcourse->course->fullname. '</b>';
            return $this->content;
        }

        if (!enrol_is_enabled('self')) {
            $this->errors[] = 'self enrolment is not enabled';
            return $this->writeErrors($this->content);
        }

        if (!$enrol = enrol_get_plugin('self')) {
            $this->errors[] = 'unable to enrol self';
            return $this->writeErrors($this->content);
        }
        if (!$instances = $DB->get_records('enrol', array('enrol' => 'self', 'courseid' => $bestcourse->course->id, 'status' => ENROL_INSTANCE_ENABLED), 'sortorder,id ASC')) {
            $this->errors[] = 'unable to get enrol self instances';
            return $this->writeErrors($this->content);
        }

        $instance = reset($instances);
        

        $result = $enrol->enrol_self($instance);

        /*
        $timestart = $timeend = 0;
        $ue = new stdClass();
        $ue->enrolid = $instance->id;
        $ue->status = ENROL_USER_ACTIVE;
        $ue->userid = $USER->id;
        $ue->timestart = $timestart;
        $ue->timeend = $timeend;
        $ue->modifierid = $USER->id;
        $ue->timecreated = time();
        $ue->timemodified = $ue->timecreated;
        $ue->id = $DB->insert_record('user_enrolments', $ue);

        if(!$ue->id) {
            $this->errors[] = 'cannot enrol this user';
            return $this->writeErrors($this->content);
        }

/*
        role_assign($assignment['roleid'], $assignment['userid'], $context->id);
  */
        $this->content->text .= '<p class="autosubinfo">' .   get_string('enrolledto', 'block_autosubscription') . ':</p>' . '<b>' . $bestcourse->course->fullname. '</b>';
        return $this->content;


        $this->content->footer = 'Footer here...';

        return $this->content;
    }
    public function writeErrors($content) {
        foreach($this->errors as $e) {
            $content->text .= '<div class="autosuberror">' . $e . '</div>';
        }
        $this->errors = [];
    }
    public function isAutoCourse($course) {

        if(is_array($this->config->as_courses) && in_array($course->id, $this->config->as_courses)) {

            return true;
        }

        //if(preg_match('/oer/i', $course->shortname))
        //    return true;//
        return false;
    }
    public static function _dump($object, $title = false) {
        ob_start();
        self::_dumpT($object, $title);
        echo ob_get_clean();
    }
    public static function _dumpT($object, $title = false) {
?>
        <?php if($title):?>
            <h2><?php echo $title;?></h2>
        <?php endif;
        if ($object):?>
        <pre>
            <?php print_r($object);?>
        </pre>
        <?php endif;
    }
}