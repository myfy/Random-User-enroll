<?php
$string['pluginname'] = 'HTML block für automatische Kurseinschreibung';
$string['autosubscription'] = 'Automatische Kurseinschreibung';
$string['configtitle'] = 'Titel';
$string['courses'] = 'AUTO-Kurse auswählen';
$string['autosubscription:addinstance'] = 'Automatische Kurseinschreibung block hinzufügen';
$string['autosubscription:myaddinstance'] = 'Automatische Kurseinschreibung block hinzufügen';
$string['alreadyenrolled'] = 'Sie sind bereits eingeschrieben in';
$string['enrolledto'] = 'Sie wurden automatisch eingeschrieben in';
