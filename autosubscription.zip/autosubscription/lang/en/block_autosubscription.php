<?php
$string['pluginname'] = 'HTML block for autosubscription';
$string['autosubscription'] = 'Auto enrollment';
$string['configtitle'] = 'Title';
$string['courses'] = 'Courses';
$string['autosubscription:addinstance'] = 'Add a new autosubscription block';
$string['autosubscription:myaddinstance'] = 'Add a new autosubscription to the My Moodle page';
$string['alreadyenrolled'] = 'You are already enrolled to';
$string['enrolledto'] = 'You are automatically enrolled to';